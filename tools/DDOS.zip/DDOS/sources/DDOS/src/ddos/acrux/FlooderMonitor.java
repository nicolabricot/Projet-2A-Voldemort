/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ddos.acrux;

/**
 *
 * @author acrux
 */
public interface FlooderMonitor {

    public void requested();
    public void failed();
}